-- DROP TABLE IF EXISTS Majors;

-- CREATE TABLE Majors (
--     major       VARCHAR(12),
-- 	description VARCHAR,
-- 	PRIMARY KEY(major)
-- );

INSERT INTO Majors(major,description) VALUES('CptS','Computer Science'),
									        ('EE','Electrical Engineering'),
											('CptE','Computer Engineering'),
											('CE','Civil Engineering'),
											('ME','Mechanical Engineering'),											
											('CHE','Chemical Engineering'),																						
											('MATH','Mathematics');
